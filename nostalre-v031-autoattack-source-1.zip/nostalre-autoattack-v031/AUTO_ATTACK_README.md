# Experimental Auto Attack patch for nostalRE v0.3.1 source

This source-only patch changes the existing on-screen Attack control label to `AUTO`. Tapping it toggles automatic targeting on/off. While enabled, the client selects the nearest living, non-pet monster among entities currently loaded by the client, within 20 cells, and reuses the existing attack/move request path. When a target dies or disappears, it scans again.

Important limitations:
- This is an experimental source modification, not a compiled or tested APK.
- It only scans entities already present in the client world; it does not reveal monsters outside the loaded/visible area.
- The server remains authoritative and may reject attacks based on map rules, range, status, or other restrictions.
- The original `nostalRE v0.3.1` APK and source are not modified; this is a separate working copy.
- Build with the repository's pinned Rust toolchain (`rust-toolchain.toml`) and the project's Android build instructions/toolchain.
