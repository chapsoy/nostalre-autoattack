# Configuration

The client reads `config.json` from the working directory at startup
(`Config::load_or_default` in [`client/src/config.rs`](../client/src/config.rs)). When
the file is absent we write a fresh one filled with the defaults listed below.
When it is present but fails to parse we log a warning and fall back to the full
default set, leaving the file untouched.

Every key is optional: the struct carries `#[serde(default)]`, so a missing key
takes its default and an unknown key is ignored. The Mandatory column therefore
marks the keys we must set to a real value for the client to connect and load
resources, not keys the parser requires.

We rewrite `config.json` at runtime whenever a persisted setting changes (sound
options, graphic options, keybindings, window layout, character slot, and the
`/effect`-family slash commands). Hand edits made while the client is running
are lost on the next save.

## Top level

| Config key | Description | Default value | Mandatory |
| --- | --- | --- | --- |
| `login_servers` | Selectable connection servers. The first is used by default; with more than one entry the client shows a server selection screen after login. See [Login server](#login-server). | `[{"name": "Local", "host": "127.0.0.1", "port": 6900}]` | Yes |
| `keep_login_id` | Store the last login ID in `saved_username` and pre-fill it on the login screen. The password is never stored. | `false` | No |
| `saved_username` | Login ID written back by the login screen when `keep_login_id` is on. | `""` | No |
| `solo` | Set by Ragnarok Solo's hub: `{"username", "password", "char_id"}`, log in and enter that character directly, skipping the login and character select screens. | none | No |
| `screen_width` | Requested initial window width, in logical pixels. Multiplied by the OS scale factor, not by `dpi_scale`. Only a request, and rewritten on exit: see [Window size](#window-size). | `1024` | No |
| `screen_height` | Requested initial window height, in logical pixels. Same handling as `screen_width`. | `768` | No |
| `fullscreen` | Start borderless fullscreen. Also toggled from the graphic options window. | `false` | No |
| `dpi_scale` | UI scale in percent. `125.0` means 1.25x. Values at or below `0` fall back to 1.0x. | `125.0` | No |
| `grf_paths` | GRF archives to mount, in priority order. | `["data/data.grf"]` | Yes |
| `data_dir` | Directory of files extracted from a GRF. Its contents mirror the inside of the archive's `data/` folder (`sprite/…`, `texture/…`) and take priority over every entry in `grf_paths`. | `null` | No |
| `bgm_path` | Directory on disk holding the BGM tracks. Read from the filesystem, not from the GRF. | `"BGM"` | No |
| `emblem_path` | Directory where downloaded guild emblems are cached. | `"emblem"` | No |
| `bgm_volume` | Background music volume, `0.0` to `1.0`. | `0.8` | No |
| `sfx_volume` | Sound effect volume, `0.0` to `1.0`. | `0.8` | No |
| `bgm_enabled` | Play background music. When off the effective BGM volume is `0.0`. | `true` | No |
| `sfx_enabled` | Play sound effects. When off the effective SFX volume is `0.0`. | `true` | No |
| `free_camera` | Screenshot escape hatch: drops the pitch band, the indoor rotation clamp and the zoom clamp. Off keeps the original game's bands. | `false` | No |
| `fog` | Apply the map's RSW fog settings. | `true` | No |
| `show_skill_effects` | The `/effect` flag. When false, one-shot skill, attack and item effects are dropped; keyed persistent visuals such as auras stay. | `true` | No |
| `no_item_amount_question` | NPC shop "Toggle Item Amount.": dragging a stack in or out of the sell basket moves all of it instead of asking for a count. | `false` | No |
| `battle_mode` | Hotkey bar battle mode: number keys trigger hotkeys instead of typing into chat. | `false` | No |
| `hotkey_visible_rows` | Number of hotkey bar rows shown. | `1` | No |
| `refuse_trade` | Auto-decline incoming trade requests. | `false` | No |
| `refuse_party_invite` | Auto-decline incoming party invitations. | `false` | No |
| `map_recovery_command` | Chat command sent by the map-recovery window's warp button when a map cannot be loaded because its data is missing from the GRF. | `"@go prontera"` | No |
| `last_char_slot` | Slot of the character selected last, restored to preselect it and its page on the next character-select screen. Client-side only; the server sends no last-used marker. | `null` | No |
| `account_backgrounds` | GRF texture paths for the account-screen background. One is picked at random per session and stretched behind the login, server and character screens. Empty or all-missing falls back to the solid clear color. | `["data/texture/유저인터페이스/rag_title.bmp", "data/texture/유저인터페이스/rag_title2.bmp", "data/texture/유저인터페이스/rag_title3.bmp"]` | No |
| `admin_account_ids` | Account ids treated as GM. Their characters use the Operator body sprite and render their name, guild name and chat in yellow. | `[]` | No |
| `see_self_as_gm_when_gm` | When the local player's account id is in `admin_account_ids`, also render it as a GM to itself. No effect for non-GM accounts. | `false` | No |
| `debug_network_delay_ms` | Artificial delay applied to outgoing packets, in milliseconds. Testing aid. | `0` | No |
| `shortcut_commands` | Chat commands bound to Alt+1 through Alt+0 by the Shortcut List window. Ten slots. | `["/!", "/?", "/ho", "/lv", "/swt", "/ic", "/an", "/ag", "/$", "/..."]` | No |
| `keybindings` | Key chord per hotkey action. Missing actions are filled from the defaults at load time. See [Keybindings](#keybindings). | all 22 actions bound, listed in [Keybindings](#keybindings) | No |
| `emotion_keys` | Trigger key per emote, keyed by emote type. See [Emotion keys](#emotion-keys). | `{}` | No |
| `window_state` | Saved position, open and collapsed state per UI window. See [Window state](#window-state). | `{}` | No |
| `display` | Name plate, damage and cast bar visibility. See [display](#display). | `{"show_other_damage": true, "show_other_cast_bars": true, "hide_name_player": false, "hide_name_monster": false, "hide_name_npc": false, "show_level_aura": true}` | No |
| `snap` | Mouse snapping targets. See [snap](#snap). | `{"monster_no_skill": false, "monster_skill": true, "item": false}` | No |
| `debug` | Trace toggles. See [debug](#debug). | `{"trace_packet": "none", "trace_effects": false, "trace_input": false, "trace_texture_load": false, "trace_sprite_scale": false}` | No |
| `accessibility` | Name plate weight, and the geometry and colours of the overhead HP, monster HP, SP and cast bars. See [accessibility](#accessibility). | see [accessibility](#accessibility) | No |
| `custom` | Behaviour the original game has no counterpart for. See [custom](#custom). | see [custom](#custom) | No |

## Login server

Each entry of `login_servers`.

| Config key | Description | Default value | Mandatory |
| --- | --- | --- | --- |
| `name` | Label shown on the server selection screen. | `"Local"` | Yes |
| `host` | Login server hostname or IP. | `"127.0.0.1"` | Yes |
| `port` | Login server port. | `6900` | Yes |
| `web_port` | Port of the server's web server (guild emblems; rAthena's, for packet versions past 2020-03). | `8888` | No |

## display

| Config key | Description | Default value | Mandatory |
| --- | --- | --- | --- |
| `display.show_other_damage` | Show damage numbers for hits not involving the local player. | `true` | No |
| `display.show_other_cast_bars` | Show cast bars over other entities. | `true` | No |
| `display.hide_name_player` | Hide player name plates. | `false` | No |
| `display.hide_name_monster` | Hide monster name plates. | `false` | No |
| `display.hide_name_npc` | Hide NPC name plates. | `false` | No |
| `display.show_level_aura` | Render the level 99 aura. | `true` | No |

## snap

Mouse snapping pulls the cursor onto a valid target. Companions always snap and
have no toggle.

| Config key | Description | Default value | Mandatory |
| --- | --- | --- | --- |
| `snap.monster_no_skill` | Snap to monsters when no entity-targeted skill is armed. | `false` | No |
| `snap.monster_skill` | Snap to monsters while an entity-targeted skill waits for its click. | `true` | No |
| `snap.item` | Snap to floor items. | `false` | No |

## debug

| Config key | Description | Default value | Mandatory |
| --- | --- | --- | --- |
| `debug.trace_packet` | Packet logging level: `"all"`, `"unhandled"` or `"none"`. | `"none"` | No |
| `debug.trace_effects` | Log effect creation and lifetime. | `false` | No |
| `debug.trace_input` | Log keyboard and mouse input dispatch. | `false` | No |
| `debug.trace_texture_load` | Log every texture load and its resolved GRF key. | `false` | No |
| `debug.trace_sprite_scale` | On map entry, log how many screen pixels one sprite texel covers, and the upscale factor derived from it. See [Texture filtering](#texture-filtering). | `false` | No |

## accessibility

The bars drawn over an entity's head: HP, the SP bar stacked under it, for a
4th job the AP bar under that, and the cast bar above. The defaults reproduce what the client drew before these keys
existed. Monsters take `monster_hp_bar`; every other entity, the local player
included, takes `hp_bar`.

Colours are `"#RRGGBB"` or `"#RRGGBBAA"`, case-insensitive. A malformed colour
fails the whole parse, and the client falls back to the full default set with a
warning.

`width` and `height` are in unscaled pixels. The HP bar's height also drives
what sits under it: the SP bar is stacked directly below, and the name plate
below whichever of the two was drawn last.

`fill_color_low` replaces `fill_color` below a quarter of the bar. The SP and
cast defaults repeat `fill_color` there, so only the two HP bars change colour
as they drain; give them different values and the SP or cast bar gets a low
warning colour too.

Write every field of a bar you override. A bar entry present but incomplete
takes its missing fields from the `hp_bar` defaults, so a `cast_bar` written as
`{"width": 80.0}` gets height `5.0` and a green fill, not `7.0` and `#00CC00`.

| Config key | Description | Default value | Mandatory |
| --- | --- | --- | --- |
| `accessibility.bold_name_plates` | Draw name plates, floor-item labels and the pending-skill level in a bold weight with a heavier outline. The original game has one weight only. Also toggled from the graphic options window. | `false` | No |
| `accessibility.hp_bar.width` | HP bar width. | `60.0` | No |
| `accessibility.hp_bar.height` | HP bar height. | `5.0` | No |
| `accessibility.hp_bar.background_color` | Colour behind the fill. | `"#424242"` | No |
| `accessibility.hp_bar.border_color` | Frame, one pixel wide. | `"#10189C"` | No |
| `accessibility.hp_bar.fill_color` | Fill at or above a quarter HP. | `"#10EF21"` | No |
| `accessibility.hp_bar.fill_color_low` | Fill below a quarter HP. | `"#FF0000"` | No |
| `accessibility.monster_hp_bar.width` | Monster HP bar width. | `60.0` | No |
| `accessibility.monster_hp_bar.height` | Monster HP bar height. | `5.0` | No |
| `accessibility.monster_hp_bar.background_color` | Colour behind the fill. | `"#424242"` | No |
| `accessibility.monster_hp_bar.border_color` | Frame, one pixel wide. | `"#10189C"` | No |
| `accessibility.monster_hp_bar.fill_color` | Fill at or above a quarter HP. | `"#FF00E7"` | No |
| `accessibility.monster_hp_bar.fill_color_low` | Fill below a quarter HP. | `"#FFFF00"` | No |
| `accessibility.sp_bar.width` | SP bar width. | `60.0` | No |
| `accessibility.sp_bar.height` | SP bar height. | `5.0` | No |
| `accessibility.sp_bar.background_color` | Colour behind the fill. | `"#424242"` | No |
| `accessibility.sp_bar.border_color` | Frame, one pixel wide. | `"#10189C"` | No |
| `accessibility.sp_bar.fill_color` | SP fill. | `"#1863DE"` | No |
| `accessibility.sp_bar.fill_color_low` | Fill below a quarter SP. | `"#1863DE"` | No |
| `accessibility.ap_bar.width` | AP bar width (4th jobs, under SP). | `60.0` | No |
| `accessibility.ap_bar.height` | AP bar height. | `5.0` | No |
| `accessibility.ap_bar.background_color` | Colour behind the fill. | `"#424242"` | No |
| `accessibility.ap_bar.border_color` | Frame, one pixel wide. | `"#10189C"` | No |
| `accessibility.ap_bar.fill_color` | AP fill. | `"#FFC663"` | No |
| `accessibility.ap_bar.fill_color_low` | Fill below a quarter AP. | `"#FFC663"` | No |
| `accessibility.cast_bar.width` | Cast bar width. | `60.0` | No |
| `accessibility.cast_bar.height` | Cast bar height. | `7.0` | No |
| `accessibility.cast_bar.background_color` | Colour behind the fill. | `"#424242"` | No |
| `accessibility.cast_bar.border_color` | Frame, one pixel wide. | `"#10189C"` | No |
| `accessibility.cast_bar.fill_color` | Cast progress fill. | `"#00CC00"` | No |
| `accessibility.cast_bar.fill_color_low` | Fill over the first quarter of the cast. | `"#00CC00"` | No |

## custom

The defaults match the original game. Most keys are off for that reason;
`custom.filtering` and `custom.sound.stereo` are on, because there the original's
behaviour is the enabled one.

| Config key                                | Description                                                                                                                                                                                                                        | Default value | Mandatory |
|-------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|-----------|
| `custom.boss_aura`                        | Green aura under boss monsters at level 99 or above.                                                                                                                                                                               | `false`       | No        |
| `custom.aura_level`                       | Base level a player's aura is drawn from (the level 99 aura, `display.show_level_aura`). The original game hard-codes 99. | `99` | No |
| `custom.fog_scale`                        | Multiplies both fog distances, so a wider view than the original game's is not swallowed by fog. See [Fog scale](#fog-scale).                                                                                                      | `1.0`         | No        |
| `custom.hd.enabled`                       | HD graphics: the scene draws into its own target and is composited before the UI. Settings, Graphics, HD: turning it on applies on restart, turning it off stops the effects at once. `/hd` flips the effects for this session only, for comparing, and saves nothing. A `custom.hd` that does not parse falls back to these defaults, keeping the rest of the config. | `false` | No |
| `custom.hd.preset`                        | `low`, `medium`, `high`, `ultra` or `custom`. `low` keeps an 8-bit scene target and has no bloom; the others use a half-float target where the GPU can render, filter and blend it. `medium` has a narrower bloom. | `"high"` | No |
| `custom.hd.bloom`                         | Bloom strength, `0` to `2`: the glow around light brighter than white (skill effects stacking up). `0` turns it off. Settings, Graphics, HD sets it live, `0` to `1` in steps of 0.05. | `0.6` | No |
| `custom.hd.grade`                         | Colour grade strength, `0` to `1`: a colour mood per map family (warm towns, green fields, desert, cold ruins, sickly swamps, volcanic, snowy), fading over a second on a map change. `0` turns it off. Settings, Graphics, HD sets it live. | `0.8` | No |
| `custom.hd.vignette`                      | Darken the screen's corners a little. Live from Settings. | `true` | No |
| `custom.hd.lamp_glow`                     | World glow, `0` to `1`: the bright parts of lamp, torch, candle and lantern textures on map models (by file name) glow. Needs bloom (not `low`, bloom above `0`). `0` turns it off. Live from Settings. | `0.6` | No |
| `custom.hd.light_pools`                   | World glow, `0` to `1`: ground lit by the map's baked lights glows softly. Needs bloom and lightmaps. `0` turns it off. Live from Settings. | `0.5` | No |
| `custom.hd.grass`                         | Grass density, `0` to `1`: swaying tufts on ground whose texture is a meadow, grass or forest floor (or looks green), fewer on hills and dirt, none indoors or under water. The quality preset sets tufts per cell (`low` 4, `medium` 6, `high` 8, `ultra` 10) and how many are drawn per frame at most, nearest first (`low` 20k, `medium` 40k, `high` 80k, `ultra` 140k); a preset change applies at once. An optional blade picture at `data\texture\nostalre\grass.png` in the game data replaces the built-in blades. `0` turns it off. Live from Settings. | `1.0` | No |
| `custom.hd.flora`                         | Flora, `0` to `1`: ferns, mushrooms and flowers in patches among the grass (`custom.hd.grass`): about 1 in 40 tufts on forest floor and 1 in 120 on meadows at `0.5`, none on hills, dirt, paths or in towns; `1` doubles it. Drawn with the grass (its density and quality preset apply). `0` grass only. Live from Settings. | `0.5` | No |
| `custom.hd.sun_glow`                      | World glow, `0` to `1`: near-white surfaces the sun falls on glow faintly. Needs bloom. `0` turns it off. Live from Settings. | `0.3` | No |
| `custom.hd.scene_light`                   | Softer baked light (lamp colours lean white, bright bakes roll off), baked shadows on floors only, and the map's lamps lighting the ground near them. The quality preset sets how many lamps the ground takes (`low` 0, `medium` 8, `high` and `custom` 16, `ultra` 32). Live from Settings. | `true` | No |
| `custom.hd.cloud_shadows`                 | Cloud shadows drifting over the land, `0` to `1`; none indoors. `0` turns them off. Live from Settings. | `0.6` | No |
| `custom.hd.night_look`                    | At night (`@night`), outdoors: dim blue moonlight over 3 seconds, lamp pools stay lit. Off: the original's mild dimming. Live from Settings. | `true` | No |
| `custom.hd.night_darkness`                | How dark nights are outdoors with `night_look` on, `0` to `1`: `0.6` as designed, `0` dusk-like (the first HD night), `1` near black. Live from Settings. | `0.6` | No |
| `custom.hd.lamp_light`                    | How strongly lamp models (street lamps, lanterns) light the ground at night, `0` to `1`: `0.5` as designed, `1` twice that, `0` none. Live from Settings. | `0.5` | No |
| `custom.hd.player_light`                  | At night outdoors with `night_look` on: a warm torch around the player. Live from Settings. | `false` | No |
| `custom.hd.day_cycle`                     | Outdoors, one game day per real hour on the UTC clock: dawn (minutes 0-5), the sun crossing the sky (the map's own light at 22:30), golden dusk (40-45), night (45-60, run by the server: `day_duration` 2700000 and `night_duration` 900000 in rathena-nostalre). The server's night always wins (`@night`, `@day`, maps without night). `/sky MM:SS` previews a minute of the hour for the session, `/sky off` goes back to the clock. Off: always the map's midday light. Live from Settings. | `true` | No |
| `custom.hd.sun_shadows`                   | Sun shadows, `0` to `1`: the share of sunlight a shadow takes away (the sky's light stays). Trees, buildings, cliffs and animated models cast them from the sun as it crosses the sky (`day_cycle`), faintly from the moon at night; outdoors only. Quality by preset: `low` none, `medium` 1024 px with 1 lookup, `high` 2048 px with 9, `ultra` 2048 px with 25. While they run, the map's baked (fixed-sun) shadows step aside on the ground, grass and characters. `0` turns them off. Live from Settings. | `0.65` | No |
| `custom.sound.act_percent`                | Percentage of ACT frame sounds (monster grunts, footsteps) that play. `100` plays all of them.                                                                                                                                     | `100`         | No        |
| `custom.sound.stereo`                     | Pan world sounds across the stereo field. Off keeps distance attenuation but centres everything.                                                                                                                                   | `true`        | No        |
| `custom.sound.play_when_unfocused`        | Keep the mixer running while the window is not focused. The original game always pauses.                                                                                                                                           | `false`       | No        |
| `custom.window.exclude_close_via_esc`     | Windows Escape must leave alone, by the names in `ESC_WINDOW_NAMES` (`client/src/ui/escape.rs`), matched case- and space-insensitively. Escape then moves on to the next window behind them. Unknown names are logged and ignored. | `[]`          | No        |
| `custom.window.wrap_item_info_title`      | Wrap a long item name inside the item information window, pushing the description down. The original game keeps it on one line. | `false` | No |
| `custom.skill.al_teleport.separate_lvl`   | Give Teleport a level picker in the skill tree, the way Fire Bolt has one. See [Forced level select](#forced-level-select).                                                                                                        | `false`       | No        |
| `custom.skill.al_teleport.skip_lvl1_menu` | Answer a level 1 Teleport's warp list without showing it, so the cast warps straight away. See [Skipping the level 1 warp list](#skipping-the-level-1-warp-list).                                                                  | `false`       | No        |
| `custom.skill.weapon_aura`                | Auras drawn around the bearer's weapon while a status lasts: flames or a pulsing glow, in colours of your choice, one rule per status. See [Weapon auras](#weapon-auras).                                                           | `[]`          | No        |
| `custom.skill.body_effect`                | Effects around the body while a status lasts or a counter is up: orbs, an aura underfoot, an outline glow, rising motes. The counters kRO draws keep its look where no rule fits. See [Body effects](#body-effects).          | `[]`          | No        |
| `custom.accessibility`                    | Deprecated spelling of `accessibility.bold_name_plates`. A `true` here still turns bold plates on at load time, and is not written back: the next config save carries the new key only.                                            | `false`       | No        |
| `custom.latency_coupled_walk`             | Replay walks against the server clock as the original game does: read 72 ms behind the estimate and corrected in 144 ms steps, so the walk cycle stalls and jumps under lag. Off keeps the smooth local-clock walk.                | `false`       | No        |
| `custom.filtering.world`                  | Filter ground and model textures, over a mip chain. Off point-samples them. See [Texture filtering](#texture-filtering).                                                                                                           | `true`        | No        |
| `custom.filtering.effects`                | Filter effect textures, both the STR ones and the primitive ones. See [Texture filtering](#texture-filtering).                                                                                                                     | `true`        | No        |
| `custom.filtering.sprites`                | Filter entity sprites. See [Texture filtering](#texture-filtering).                                                                                                                                                                | `true`        | No        |
| `custom.filtering.sprite_upscale`         | Enlarge entity sprites before upload so filtering softens a fraction of a source texel. Ignored while `custom.filtering.sprites` is off. See [Sprite upscale](#sprite-upscale).                                                    | `false`       | No        |

## Fog scale

`data/fogparametertable.txt` gives a fogged map a near and a far value, both
fractions of the original game's view frustum. The client turns each into a
world distance from the camera:

```text
distance = 10 + fraction * 1490
```

Fog then ramps linearly between the two, measured as the straight-line distance
from the eye rather than depth into the screen. For the `0.2 / 0.8` entry most
maps use, that is fully clear at 308 units and fully fogged at 1202.

Those numbers come from a 4:3 window and a camera that did not pull back as far
as ours does. Two things push a modern view past them. Zooming out moves the eye
away from the ground, and outdoor camera distance runs to 1500, past the point
where everything is fogged. A wider aspect ratio also puts the corners of the
screen further from the eye than the centre, so an ultrawide fogs at its edges
where a 4:3 window did not. Resolution on its own changes nothing, since the
distances are in world units.

`custom.fog_scale` multiplies both distances, keeping the ramp's shape:

| `custom.fog_scale` | `0.2 / 0.8` entry |
| --- | --- |
| `1.0` | 308 → 1202 |
| `1.5` | 462 → 1803 |
| `2.0` | 616 → 2404 |
| `3.0` | 924 → 3606 |

`2.0` puts the far end beyond maximum zoom-out. Values below `1.0` pull fog in.

The value is read once when the renderer is created. Changing the key needs a
restart. It has no effect on maps with no fog table entry, or while `/fog` is
off.

## Texture filtering

The original game sets one filter for the whole device and never changes it:
magnification and minification are both linear. The mip filter is the only
per-pass state, linear while the ground and model faces are drawn and off
everywhere else. We match that by default. Each `custom.filtering` key turns
filtering off for one family of textures, which is a deviation.

The three families are also checkboxes in the graphic options window, on the
`Texture Filtering:` row: Esc, then Graphics. A ticked box is the key set to
`true`. A change there applies immediately and is written back to `config.json`.

### custom.filtering.world

| Value | Effect |
| --- | --- |
| `true` | Ground and model textures sample bilinearly, over a mip chain built at load time by halving the image down to 1x1. Texels left near the magenta colour key are diluted by the filter until they fail the `0.81` alpha test in `terrain.wgsl` and `model.wgsl`, so a stray keyed pixel disappears instead of showing as a magenta dot. Costs one third more texture memory and one `write_texture` call per mip level. |
| `false` | One mip level, point sampling. Texels stay hard, including the colour-key fringes some model textures carry. |

Toggling this at runtime rebuilds the world textures a loaded map already
uploaded, which re-reads and re-decodes each of them.

### custom.filtering.effects

| Value | Effect |
| --- | --- |
| `true` | Effect textures sample bilinearly. Both effect paths agree: the primitive textures loaded through `load_keyed_texture` and the STR ones cached in `StrEffectCache`. |
| `false` | Both paths point-sample. |

Toggling this at runtime rebuilds the primitive effect textures in place and
drops the STR cache entries, which reload when their effect next spawns.

### custom.filtering.sprites

| Value | Effect |
| --- | --- |
| `true` | Entity sprites sample bilinearly. Sprite silhouettes gain a dark rim: a transparent texel is stored as black with alpha 0, and the filter mixes that black into the edge. The original game has the same upload but draws its billboards at one texel per pixel, where a bilinear tap returns the texel unchanged. Our billboards are scaled by `perspective_scale * zoom / 75`, so they rarely land on that ratio. |
| `false` | Entity sprites point-sample. |

Toggling this at runtime reloads every player, monster and NPC, the local
character and the guild head icons. Carts, falcons, the cursor, emotes, damage
digits and floor items are spawned by events or loaded once, so they keep the
filter they were uploaded with until the next login.

## Sprite upscale

`custom.filtering.sprite_upscale` enlarges each sprite frame before upload, with
a nearest filter so the interior stays pixel exact. The bilinear tap then only
softens the boundary between enlarged texels, which narrows the blurred edge and
the dark rim to one enlarged texel. It does nothing while
`custom.filtering.sprites` is off, since point sampling has no edge to narrow.

The factor is not a setting. On map entry the client measures the magnification
its own camera produces and rounds it up:

```text
ratio  = perspective_scale(camera.target) * map.zoom / 75 * dpi_scale
factor = clamp(ceil(ratio), 1, 4)
```

`perspective_scale` is the function the render path itself calls, so the measured
ratio cannot drift from what is drawn. Rounding up keeps the softened edge under
one screen pixel. The cost of that guarantee is that a ratio of `1.05` rounds to
`2`, which is four times the memory for a five percent overshoot.
`debug.trace_sprite_scale` prints the measurement and the chosen factor on every
map entry, so we can see when that happens:

```text
[sprite-scale] texel_to_pixel=1.24 dpi=1.00 camera_distance=200 upscale=2
```

Memory grows with the square of the factor and upload time grows with it as well.
Measured on `검사_남.spr`, the male swordman body, 118 frames:

| Factor | Resize time | Texture memory |
| --- | --- | --- |
| 1 | 0 ms | 1.23 MiB |
| 2 | 17.2 ms | 4.93 MiB |
| 3 | 30.8 ms | 11.09 MiB |
| 4 | 48.0 ms | 19.72 MiB |

That cost is paid once per sprite file per login: the sprite cache is keyed by
path and shared between entities, and it is cleared on logout, not on map change.

`Sprite upscale` is the checkbox below the filtering row in the graphic options
window. Ticking it re-derives the factor from the current camera, reloads the
sprites the same way the `Sprites` box does, and reports the factor it chose in
the chat window:

```text
Sprite upscale: 2x
```

While `custom.filtering.sprites` is off the message says so instead, since there
is nothing for the upscale to sharpen.

## Forced level select

The skill tree shows a level picker, the `< Lv : n / max >` arrows, only for
skills listed in `data/leveluseskillspamount.txt`. That file carries an SP cost
per level, and a skill absent from it is cast at the learned level with no way
to pick a lower one. Fire Bolt is listed, Teleport is not.

`custom.skill.al_teleport.separate_lvl` adds Teleport to the set at table load
time. The picker then behaves as it does for any listed skill, and the selected
level is what gets sent on cast. The SP figure in the row stays the flat cost
the server sent for the skill, because no per-level column exists to read.

The override is applied once, when the GRF tables are loaded at startup.
Changing the key needs a restart.

## Skipping the level 1 warp list

A level 1 Teleport does not warp on its own. The server answers the cast with a
`ZC_WARPLIST` holding one entry, `Random`, and waits for the client to pick it.
The window with its single button is what the original game does, and we match
it.

`custom.skill.al_teleport.skip_lvl1_menu` answers that packet directly instead
of opening the window. The reply is the same one the button would have sent, so
the server sees no difference.

The list has to be exactly one `Random` entry for the shortcut to fire. A level
2 cast sends `Random` plus the save point, which is a real choice, so that list
always reaches the window.

```mermaid
flowchart TD
    A[ZC_WARPLIST arrives] --> B{skip_lvl1_menu on?}
    B -- no --> W[Open warp list window]
    B -- yes --> C{Teleport, and the only entry is Random?}
    C -- no --> W
    C -- yes --> D[Send CZ_SELECT_WARPPOINT Random]
    W --> E[Player clicks] --> D
```

The server has its own version of this, `skip_teleport_lv1_menu` in
`conf/battle/skill.conf`, which suppresses the packet entirely. Prefer that one
when we control the server: it saves the round trip. The client key exists for
servers we do not control.

## Weapon auras

The original game lights a weapon in only a few fixed ways (Aura Blade's steady blue-white glow, Magnum Break's
spark). `custom.skill.weapon_aura` draws an aura of our own around the weapon instead, for as long as a status lasts,
on any unit that carries it:

```json
"skill": {
  "weapon_aura": [
    { "status": "EFST_AURABLADE", "style": "pulse", "inner": "#EAF4FF", "outer": "#3C78FF" },
    { "status": "EFST_<NAME>",    "style": "flame", "inner": "#FFEB73", "outer": "#D92608" }
  ]
}
```

| Field | Meaning |
|---|---|
| `status` | The status, by name: `EFST_AURABLADE`, `AURABLADE` or `Aurablade` alike |
| `style` | `flame`: flames rising off the weapon and breaking into tongues. `pulse`: a glow hugging the weapon's outline, brightest on its edge, breathing a faint ring outward |
| `inner` | The colour at the weapon, where the aura is hottest or brightest |
| `outer` | The colour it fades to, away from the weapon |

The aura replaces the original's own light on that weapon while it shows, follows the weapon through every motion,
and leaves the body alone. One status, one rule; a unit with two configured statuses shows one of them.

It is drawn by `fs_weapon_aura` in `lib/renderer/src/shaders/sprite.wgsl`, around the weapon's own shape, on a quad
the weapon clip grown by `WEAPON_AURA_MARGIN_PX`. The pulse's strength, spread and breath are the `PULSE_*`
constants there. A pulse reads at most 40 texture samples a pixel and a flame about 9, so a few auras on screen cost
little; many at once on a phone are worth watching.

## Body effects

`custom.skill.body_effect` puts effects of our own around a unit's body, as `weapon_aura` does around its weapon:
orbs circling it, an aura underfoot, a glow around its outline, motes rising off it. A rule fires on a status or on
a counter the server sends; every layer is optional and every field it leaves out takes the default below.

```json
"skill": {
  "body_effect": [
    {
      "status": "EFST_ENCHANTBLADE",
      "orbs":   { "count": 3, "outer": "#FF6A1A", "inner": "#FFF2C0" },
      "ground": { "look": "ring", "radius": 7, "outer": "#FF4400", "inner": "#FFD080" },
      "glow":   { "color": "#FF5A10", "size": 4 },
      "motes":  { "rate": 10, "outer": "#FF8A30" }
    },
    { "counter": "soul_energy", "min_count": 16, "orbs": { "max": 5, "outer": "#FFD700", "size": 3 } }
  ]
}
```

| Field | Meaning |
|---|---|
| `status` | The status, by name, as the weapon aura reads it (`EFST_ENCHANTBLADE`, `ENCHANTBLADE`, `Enchantblade`) |
| `counter` | `spirits` (a Monk's spheres, a Gunslinger's coins), `millennium_shield`, `soul_energy`, `water_charm`, `earth_charm`, `fire_charm`, `wind_charm` (a Kagerou's or Oboro's charms) |
| `jobs` | Only these jobs, by name or by the classic line they grew from (`Monk` takes a Sura); empty is anyone |
| `min_count` | From this count up. Of the rules that fit, the highest `min_count` reached wins, a rule with `jobs` before one without |

| Layer | Fields (defaults) |
|---|---|
| `orbs` | `count` (none: one per counted unit, 1 for a status), `max` 20, `swell` 0 (each count past `max` makes the orbs that share bigger and lights a halo round them: a Monk's spheres past five), `radius` 7, `height` 11, `speed` 1 (a Monk's spheres; 0 holds the circle still), `spin` 0 (degrees a second each orb turns about its own middle, negative the other way), `size` 1.6, `wobble` 0.5, `even` true (else 72 degrees apart), `upright` false (true: a wheel standing at the body's back, turning with it, instead of a ring round it), `back` 0 (how far behind the body the circle's middle sits), `shade` 0 (how much darker an upright wheel's orbs go toward its bottom: none at the top, that share at the bottom), `shrink` 0 (how much smaller, the same way), `look` `glow`, `inner` `#FFFFFF`, `outer` `#5A32FF`, `intensity` 0.8 |
| `ground` | `look` `ring` or `disc`, `radius` 6, `spin` 30 (degrees a second), `breath` 0.1 (a share of the radius), `inner` `#FFFFFF`, `outer` `#5A32FF`, `intensity` 0.6 |
| `glow` | `color` `#5A32FF`, `size` 5 (pixels at the default zoom), `breath` 1.5, `intensity` 0.7 |
| `motes` | `rate` 8 a second, `rise` 20, `life` 1.2 seconds, `spread` 5, `size` 1, `look` `spark`, `inner` `#FFFFFF`, `outer` `#5A32FF`, `intensity` 0.8 |

- `look` for orbs and motes: `glow` (a round glow with a hard edge, a Monk's spheres), `spark` (a white starburst),
  `soft` (a soft white glow), `green_flame` and `red_flame` (kRO's torch flames, animated, a soft core inside; leave
  `outer` white to keep their own colours), `water_orb`, `stone_orb`, `fire_orb` and `lightning_orb` (kRO's charm
  sprites, drawn as they are over the ground rather than as light; no core), `fire_charm`, `water_charm`,
  `earth_charm` and `wind_charm` (nostalRE's own charms, pixel-art orbs, drawn the same way; the charms' built-in
  look).
- A rule that does not read (a misspelt look or counter, a colour that is not hex) is left out with a warning in the
  log, and the rest load; a save writes every rule back as you wrote it, defaults not filled in. The weapon auras read
  the same way.
- Distances are world units: a Monk's spheres circle at radius 7, 15 above the feet. `intensity` scales the alpha,
  0 to 1; every layer fades in over about three seconds.
- A unit shows one effect a status or counter, all of them at once. The counters keep their built-in look (kRO's, but
  our own orbs for the charms; `client/src/body_effect.rs`) wherever no rule of yours fits.

It is drawn by `BodyAuraEffect` (`lib/effects/src/effects/body_aura.rs`): orbs and motes as additive billboards, the
ground aura as two ground discs, the glow as kRO's own outline copy behind the body (`BodyCopy`, as Assumptio's).

## Window size

`screen_width` and `screen_height` are passed to winit as a logical inner size
at window creation, before the surface exists. They are a request, and the
window system is free to ignore them.

- X11 and Windows honour the request.
- Wayland does not. The compositor answers with an xdg configure carrying the
  size it decided, and winit adopts that size whenever the configure has one.
  The requested size only survives when the configure leaves the size
  unspecified.

Under a tiling compositor the window is tiled by default, the configure always
carries the tile size, and these two keys have no observable effect. To see them
applied we must make the window float. The client never calls winit's
Wayland `with_name`, so the surface has no `app_id` and a compositor rule keyed
on window class will not match. Match on the title instead, which is
`nostalRE`.

The window is resizable. On exit we write the current size back to both keys, so
a resized window comes back the same size next start. The capture happens once,
at close, not on every resize event. `fullscreen: true` skips the capture and
overrides both keys at startup: the client requests the size, then immediately
switches to borderless fullscreen.

Whatever size we end up with is correct from the client's point of view. After
creation the actual physical size is read back from the window, and every
`Resized` event recomputes the UI's logical extent, so window layout follows the
compositor rather than the config.

## Window state

`window_state` maps a window id to its saved layout. The client writes this
section itself on every layout change; we normally do not hand edit it.

```json
"window_state": {
  "300": { "position": [0.0, 100.0], "open": false, "collapsed": false }
}
```

| Config key | Description | Default value | Mandatory |
| --- | --- | --- | --- |
| `position` | Window top-left in logical UI coordinates. | `[0.0, 0.0]` | No |
| `open` | Window visible. | `false` | No |
| `collapsed` | Window rolled up to its title bar. | `false` | No |

The saved state is applied once per login, not on every map change.

## Keybindings

`keybindings` maps a hotkey action name to a key chord. Missing actions are
filled from the defaults at load time, so a partial table is valid.

```json
"keybindings": {
  "ToggleInventory": { "key": "KeyB", "alt": true, "ctrl": false, "shift": false }
}
```

`key` is the winit `KeyCode` debug name (`"KeyE"`, `"Insert"`, `"Tab"`). The
action names are the `HotkeyAction` variants in
[`lib/game/src/keybinding.rs`](../lib/game/src/keybinding.rs):

| Action | Default chord |
| --- | --- |
| `ToggleInventory` | Alt + E |
| `ToggleEquipment` | Alt + Q |
| `ToggleSkillTree` | Alt + S |
| `ToggleStatus` | Alt + A |
| `ToggleBasicInfo` | Alt + V |
| `ToggleShortcutList` | Alt + M |
| `ToggleEmotion` | Alt + L |
| `ToggleQuest` | Alt + U |
| `ToggleCart` | Alt + W |
| `ToggleGuild` | Alt + G |
| `ToggleChatRoomCreate` | Alt + C |
| `ToggleParty` | Alt + Z |
| `ToggleFriends` | Alt + H |
| `ToggleHomunculus` | Alt + R |
| `ToggleMercenary` | Ctrl + R |
| `TogglePet` | Alt + J |
| `ToggleSoundOptions` | Alt + O |
| `ToggleGraphicOptions` | Alt + D |
| `SitStand` | Insert |
| `CycleMinimap` | Ctrl + Tab |
| `MercenaryFollow` | Ctrl + T |
| `ToggleWorldMap` | Ctrl + Backquote |

## Emotion keys

`emotion_keys` maps an emote type number to a key chord, using the same chord
shape as `keybindings`. Empty by default.

```json
"emotion_keys": {
  "0": { "key": "F1", "alt": false, "ctrl": true, "shift": false }
}
```

## Sample

[`config.sample.json`](../config.sample.json) is a minimal working file: the
connection server, the GRF paths, the audio directories and volumes, the login ID kept, the GM account ids, the
debug section and a few `accessibility` and `custom` settings.
Copying it to `config.json` and pointing `grf_paths` at a real archive is enough
to start the client.
