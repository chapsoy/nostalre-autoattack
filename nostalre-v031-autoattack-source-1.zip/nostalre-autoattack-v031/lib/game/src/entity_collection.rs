use crate::data_table::skill_name_table::{SkillNameTable, format_skill_display_name};
use crate::entity::{EmotionState, Entity, EntityState, EntityType, pose_secs};
use crate::mob_info::MobInfo;
use crate::movement::direction_from_positions;
use crate::skill_action::skill_pose;
use models::enums::skill_enums::SkillEnum;
use std::collections::HashMap;
use std::ops::Index;

/// How long a caster stays in its skill motion for a ground-placed skill.
pub const GROUND_SKILL_EXEC_SECS: f32 = 0.6;
const NO_DAMAGE_SKILL_EXEC_SECS: f32 = 0.6;
/// How far an NPC answers from: rAthena's `area_size` (14) and one, each way
pub const TALK_RANGE: u16 = 15;

pub struct EntityCollection {
    entities: HashMap<u32, Entity>,
    player_id: Option<u32>,
    /// Maps a player's account id (the actor id used by name/guild packets) to
    /// the entity key. For players the two differ; for other actors they match.
    account_to_key: HashMap<u32, u32>,
}

impl Default for EntityCollection {
    fn default() -> Self {
        Self::new()
    }
}

impl EntityCollection {
    pub fn new() -> Self {
        Self {
            entities: HashMap::new(),
            player_id: None,
            account_to_key: HashMap::new(),
        }
    }

    pub fn register_account_id(&mut self, account_id: u32, key: u32) {
        if account_id != key {
            self.account_to_key.insert(account_id, key);
        }
    }

    /// Resolves an actor id from a name/guild packet to an entity key, following
    /// the account-id bridge when the id is a player's account id.
    pub fn resolve_key(&self, id: u32) -> u32 {
        self.account_to_key.get(&id).copied().unwrap_or(id)
    }

    /// Inverse of [`Self::resolve_key`]: the account id a CZ request must carry
    /// to address the entity behind `key`. Every player-targeted request (trade,
    /// party/guild invite, adoption, manner points) is keyed by account id, not
    /// by the char id the entity is stored under.
    pub fn account_id_of(&self, key: u32) -> u32 {
        self.account_to_key
            .iter()
            .find(|(_, k)| **k == key)
            .map(|(account_id, _)| *account_id)
            .unwrap_or(key)
    }

    pub fn set_player_id(&mut self, id: u32) {
        self.player_id = Some(id);
    }

    pub fn player_id(&self) -> Option<u32> {
        self.player_id
    }

    pub fn player(&self) -> Option<&Entity> {
        self.player_id.and_then(|id| self.entities.get(&id))
    }

    pub fn player_mut(&mut self) -> Option<&mut Entity> {
        self.player_id.and_then(|id| self.entities.get_mut(&id))
    }

    pub fn player_job(&self) -> u16 {
        self.player().map_or(0, |e| e.job)
    }

    pub fn insert(&mut self, entity: Entity) {
        self.entities.insert(entity.id, entity);
    }

    pub fn remove(&mut self, id: u32) -> Option<Entity> {
        self.account_to_key.retain(|_, key| *key != id);
        self.entities.remove(&id)
    }

    pub fn get(&self, id: u32) -> Option<&Entity> {
        self.entities.get(&id)
    }

    pub fn get_mut(&mut self, id: u32) -> Option<&mut Entity> {
        self.entities.get_mut(&id)
    }

    pub fn iter(&self) -> impl Iterator<Item = &Entity> {
        self.entities.values()
    }

    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut Entity> {
        self.entities.values_mut()
    }

    /// The NPC closest to `from` that can be talked to, within `range` cells each way (rAthena's
    /// `npc_checknear` square): not a warp portal or a hidden trigger. Ties go to the lower id, so the pick
    /// holds from frame to frame
    pub fn nearest_talkable_npc(&self, from: (u16, u16), range: u16) -> Option<&Entity> {
        self.iter()
            .filter(|e| {
                e.entity_type == EntityType::Npc && !crate::sprite_path::is_undrawn_actor(e.job)
            })
            .map(|e| {
                let (x, y) = e.movement.cell_position();
                (x.abs_diff(from.0).max(y.abs_diff(from.1)), e)
            })
            .filter(|&(distance, _)| distance <= range)
            .min_by_key(|&(distance, e)| (distance, e.id))
            .map(|(_, e)| e)
    }

    pub fn clear(&mut self) {
        self.entities.clear();
        self.account_to_key.clear();
        self.player_id = None;
    }

    pub fn is_player(&self, id: u32) -> bool {
        self.player_id == Some(id)
    }

    pub fn clear_just_spawned_flags(&mut self) {
        for entity in self.entities.values_mut() {
            entity.just_spawned = false;
        }
    }

    pub fn clear_non_player(&mut self) {
        if let Some(pid) = self.player_id {
            self.entities.retain(|&id, _| id == pid);
            self.account_to_key.retain(|_, key| *key == pid);
        } else {
            self.entities.clear();
            self.account_to_key.clear();
        }
    }

    pub fn apply_entity_stop_move(&mut self, gid: u32, x: u16, y: u16) {
        if let Some(entity) = self.entities.get_mut(&gid) {
            entity.movement.set_position(x as f32, y as f32);
            if entity.state() == EntityState::Moving {
                entity.set_state(EntityState::Standing);
            }
        }
    }

    pub fn apply_entity_direction_changed(&mut self, gid: u32, head_dir: u8, dir: u8) {
        if let Some(entity) = self.entities.get_mut(&gid) {
            entity.head_dir = head_dir;
            entity.set_facing(dir);
        }
    }

    pub fn apply_entity_name_received(&mut self, gid: u32, name: String) {
        let key = self.resolve_key(gid);
        if let Some(entity) = self.entities.get_mut(&key) {
            entity.name = Some(match entity.entity_type {
                EntityType::Npc => name
                    .split_once("#")
                    .map(|r| r.0.to_owned())
                    .unwrap_or_else(|| name),
                _ => name,
            });
        }
    }

    pub fn apply_entity_guild_changed(&mut self, aid: u32, gdid: u32, emblem_version: i32) {
        let key = self.resolve_key(aid);
        if let Some(entity) = self.entities.get_mut(&key) {
            entity.guild_id = gdid;
            entity.guild_emblem_version = emblem_version;
            if gdid < 1 {
                entity.guild_name = None;
            }
        }
    }

    pub fn apply_entity_names_received(
        &mut self,
        gid: u32,
        name: String,
        party_name: String,
        guild_name: String,
        position_name: String,
        title: String,
    ) {
        let key = self.resolve_key(gid);
        if let Some(entity) = self.entities.get_mut(&key) {
            entity.name = Some(name);
            entity.guild_name = (!guild_name.is_empty()).then_some(guild_name);
            entity.position_name = (!position_name.is_empty()).then_some(position_name);
            entity.title = (!title.is_empty()).then_some(title);
            if entity.entity_type == EntityType::Monster {
                entity.mob_info = MobInfo::parse(&party_name);
            }
        }
    }

    pub fn apply_entity_position_name(&mut self, aid: u32, position_name: String) {
        let key = self.resolve_key(aid);
        if let Some(entity) = self.entities.get_mut(&key) {
            entity.position_name = (!position_name.is_empty()).then_some(position_name);
        }
    }

    pub fn apply_entity_emotion(&mut self, gid: u32, emotion_type: u8, duration: f32) {
        if let Some(entity) = self.entities.get_mut(&gid) {
            entity.emotion = Some(EmotionState::new(emotion_type, duration));
        }
    }

    #[allow(clippy::too_many_arguments)]
    pub fn apply_skill_casting(
        &mut self,
        gid: u32,
        target_gid: u32,
        skill: SkillEnum,
        delay_ms: u32,
        x: i16,
        y: i16,
        names: Option<&SkillNameTable>,
    ) {
        self.show_skill_chat_bubble(gid, skill, names);
        let target_pos = if target_gid != 0 {
            self.entities
                .get(&target_gid)
                .map(|e| e.movement.cell_position())
        } else if x != 0 || y != 0 {
            Some((x as u16, y as u16))
        } else {
            None
        };
        if let Some(entity) = self.entities.get_mut(&gid) {
            if let Some(tp) = target_pos {
                let sp = entity.movement.cell_position();
                if let Some(dir) = direction_from_positions(sp.0, sp.1, tp.0, tp.1) {
                    entity.set_facing(dir);
                }
            }
            let duration = delay_ms as f32 / 1000.0;
            if duration > 0.0 {
                entity.enter_casting(duration, skill);
                entity.cast_target_gid =
                    (target_gid != 0 && target_gid != gid).then_some(target_gid);
            } else {
                entity.enter_skill_exec(0.3, skill, 1);
            }
        }
    }

    pub fn apply_autocounter_channel(
        &mut self,
        gid: u32,
        face_gid: Option<u32>,
        skill: SkillEnum,
        duration_secs: f32,
    ) {
        let face_pos =
            face_gid.and_then(|g| self.entities.get(&g).map(|e| e.movement.cell_position()));
        if let Some(entity) = self.entities.get_mut(&gid) {
            if let Some((tx, ty)) = face_pos {
                let (sx, sy) = entity.movement.cell_position();
                if let Some(dir) = direction_from_positions(sx, sy, tx, ty) {
                    entity.set_facing(dir);
                }
            }
            entity.enter_casting(duration_secs, skill);
            entity.state_timer = duration_secs;
        }
    }

    pub fn apply_skill_no_damage(&mut self, skill: SkillEnum, src_gid: u32, target_gid: u32) {
        if skill == SkillEnum::TkRun && !self.entities.get(&src_gid).is_some_and(|e| e.is_running) {
            return;
        }
        let target_pos = self
            .entities
            .get(&target_gid)
            .map(|e| e.movement.cell_position());
        if let Some(entity) = self.entities.get_mut(&src_gid) {
            if let Some(dst) = target_pos {
                let src = entity.movement.cell_position();
                if let Some(dir) = direction_from_positions(src.0, src.1, dst.0, dst.1) {
                    entity.set_facing(dir);
                }
            }
            match skill_pose(skill) {
                // a no-damage skill is no combo blow: no combo window to hold for
                Some(pose) => {
                    let hold_secs = pose.hold_secs(None);
                    entity.enter_skill_exec(pose_secs(&pose, hold_secs), skill, 1);
                    entity.pose_skill_exec(&pose, hold_secs);
                }
                None => entity.enter_skill_exec(NO_DAMAGE_SKILL_EXEC_SECS, skill, 1),
            }
        }
    }

    pub fn show_skill_chat_bubble(
        &mut self,
        gid: u32,
        skill: SkillEnum,
        names: Option<&SkillNameTable>,
    ) {
        if matches!(
            skill,
            SkillEnum::StChasewalk
                | SkillEnum::DcScream
                | SkillEnum::BaFrostjoker
                | SkillEnum::ItemEnchantarms
        ) {
            return;
        }
        if self
            .entities
            .get(&gid)
            .is_some_and(|e| e.entity_type != EntityType::Monster)
        {
            let name = format_skill_display_name(skill, names);
            self.set_chat_bubble(gid, format!("{name} !!"));
        }
    }

    pub fn hides_overhead_ui(&self, gid: u32) -> bool {
        !self.is_player(gid)
            && self
                .entities
                .get(&gid)
                .is_some_and(|e| crate::sprite_path::is_hidden(e.effect_state))
    }

    pub fn set_chat_bubble(&mut self, gid: u32, message: String) {
        if self.hides_overhead_ui(gid) {
            return;
        }
        if let Some(entity) = self.entities.get_mut(&gid) {
            entity.chat_bubble = Some(crate::entity::ChatBubbleState::new(message));
        }
    }

    pub fn clear_hidden_chat_bubble(&mut self, gid: u32) {
        if !self.hides_overhead_ui(gid) {
            return;
        }
        if let Some(entity) = self.entities.get_mut(&gid) {
            entity.chat_bubble = None;
        }
    }

    pub fn apply_ground_skill(&mut self, skill: SkillEnum, src_gid: u32, x: i16, y: i16) {
        if let Some(entity) = self.entities.get_mut(&src_gid) {
            let sp = entity.movement.cell_position();
            if let Some(dir) = direction_from_positions(sp.0, sp.1, x as u16, y as u16) {
                entity.set_facing(dir);
            }
            entity.enter_skill_exec(GROUND_SKILL_EXEC_SECS, skill, 1);
        }
    }

    pub fn apply_skill_cast_cancel(&mut self, gid: u32) {
        let target_gid = if gid == 0 {
            self.player_id.unwrap_or(0)
        } else {
            gid
        };
        if let Some(entity) = self.entities.get_mut(&target_gid) {
            entity.set_state(EntityState::Standing);
            entity.state_timer = 0.0;
            entity.clear_cast();
            entity.active_skill = None;
        }
    }

    pub fn apply_action_failure(&mut self) {
        if let Some(entity) = self.player_mut() {
            entity.set_state(EntityState::Standing);
            entity.state_timer = 0.0;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::autocounter::channel_params;
    use crate::character::{Character, job_class_name};
    use crate::entity::EntityType;
    use crate::skill::{SkillData, SkillTargetType};
    use models::enums::EnumWithNumberValue;
    use models::enums::class::JobName;

    fn npc_at(id: u32, job: u16, x: u16, y: u16) -> Entity {
        Entity::new(
            id,
            EntityType::Npc,
            job,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            x,
            y,
            0,
            150,
        )
    }

    #[test]
    fn nearest_talkable_npc_skips_warps_and_far_ones() {
        let mut entities = EntityCollection::new();
        entities.insert(npc_at(1, crate::sprite_path::JT_WARPNPC, 101, 100));
        entities.insert(npc_at(2, 86, 104, 103));
        entities.insert(npc_at(3, 86, 99, 97));
        entities.insert(npc_at(4, 86, 120, 100));

        let pick = |entities: &EntityCollection, range| {
            entities
                .nearest_talkable_npc((100, 100), range)
                .map(|e| e.id)
        };
        assert_eq!(
            pick(&entities, 15),
            Some(3),
            "the warp is nearer, but is no one to talk to"
        );
        assert_eq!(
            pick(&entities, 2),
            None,
            "3 cells off, out of a 2-cell reach"
        );

        entities.insert(npc_at(5, 86, 102, 97));
        assert_eq!(pick(&entities, 15), Some(3), "a tie goes to the lower id");
    }

    fn make_entity(id: u32) -> Entity {
        Entity::new(
            id,
            EntityType::Player,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            150,
        )
    }

    #[test]
    fn player_job_follows_base_look_change() {
        let mut col = EntityCollection::new();
        col.set_player_id(100);
        let mut player = make_entity(100);
        player.job = JobName::Swordsman.value() as u16;
        col.insert(player);
        col.insert(make_entity(200));

        assert_eq!(job_class_name(col.player_job()), "Swordsman");

        col.get_mut(100)
            .unwrap()
            .apply_sprite_change(0, JobName::Knight.value() as u16);

        assert_eq!(job_class_name(col.player_job()), "Knight");
    }

    #[test]
    fn insert_get_remove_and_player() {
        let mut col = EntityCollection::new();
        col.set_player_id(100);
        col.insert(make_entity(100));
        col.insert(make_entity(200));
        col.insert(make_entity(300));

        assert!(col.player().is_some());
        assert_eq!(col.player().unwrap().id, 100);
        assert!(col.get(200).is_some());
        assert!(col.get(999).is_none());

        col.remove(200);
        assert!(col.get(200).is_none());

        col.clear_non_player();
        assert!(col.player().is_some());
        assert!(col.get(300).is_none());
    }

    #[test]
    fn names_resolve_through_account_id_bridge() {
        let mut col = EntityCollection::new();
        col.insert(make_entity(2000100));
        col.register_account_id(2000101, 2000100);

        col.apply_entity_names_received(
            2000101,
            "Stalker".to_string(),
            String::new(),
            "rg".to_string(),
            "GuildMaster".to_string(),
            "VIP".to_string(),
        );

        let e = col.get(2000100).unwrap();
        assert_eq!(e.name.as_deref(), Some("Stalker"));
        assert_eq!(e.guild_name.as_deref(), Some("rg"));
        assert_eq!(e.position_name.as_deref(), Some("GuildMaster"));
        assert_eq!(e.title.as_deref(), Some("VIP"));

        col.remove(2000100);
        col.insert(make_entity(2000101));
        col.apply_entity_name_received(2000101, "Other".to_string());
        assert_eq!(col.get(2000101).unwrap().name.as_deref(), Some("Other"));
    }

    #[test]
    fn picked_entity_resolves_back_to_the_account_id_requests_are_addressed_to() {
        let mut col = EntityCollection::new();
        col.insert(make_entity(2000100));
        col.register_account_id(2000101, 2000100);
        col.insert(make_entity(110000));

        assert_eq!(col.account_id_of(2000100), 2000101);
        assert_eq!(col.resolve_key(col.account_id_of(2000100)), 2000100);
        assert_eq!(col.account_id_of(110000), 110000);
    }

    #[test]
    fn option_change_under_account_id_cloaks_another_player() {
        use crate::sprite_path::{HiddenRender, HiddenViewer, OPTION_CLOAK, hidden_render};

        let mut col = EntityCollection::new();
        col.insert(make_entity(2000100));
        col.register_account_id(2000101, 2000100);

        let key = col.resolve_key(2000101);
        col.get_mut(key).unwrap().effect_state = OPTION_CLOAK;

        let e = col.get(2000100).unwrap();
        assert_eq!(
            hidden_render(e.effect_state, HiddenViewer::Other, false),
            HiddenRender::Skip
        );
    }

    #[test]
    fn mob_info_string_is_parsed_for_monsters_only() {
        let mut col = EntityCollection::new();
        let mut monster = make_entity(100);
        monster.entity_type = EntityType::Monster;
        col.insert(monster);
        col.insert(make_entity(200));

        for id in [100, 200] {
            col.apply_entity_names_received(
                id,
                "Poring".to_string(),
                "HP: 100/200".to_string(),
                String::new(),
                String::new(),
                String::new(),
            );
        }

        let monster = col.get(100).unwrap();
        assert_eq!(monster.mob_info.as_ref().unwrap().hp_ratio(), Some(0.5));
        assert_eq!(monster.hp, None);

        let player = col.get(200).unwrap();
        assert!(player.mob_info.is_none());
        assert_eq!(player.name.as_deref(), Some("Poring"));
    }

    #[test]
    fn stop_move_updates_position_and_state() {
        let mut col = EntityCollection::new();
        let mut entity = make_entity(100);
        entity.set_state(EntityState::Moving);
        col.insert(entity);

        col.apply_entity_stop_move(100, 10, 20);
        let e = col.get(100).unwrap();
        assert_eq!(e.movement.cell_position(), (10, 20));
        assert_eq!(e.state(), EntityState::Standing);
    }

    #[test]
    fn stop_move_ignores_non_moving_state() {
        let mut col = EntityCollection::new();
        let mut entity = make_entity(100);
        entity.set_state(EntityState::Attacking);
        col.insert(entity);

        col.apply_entity_stop_move(100, 5, 5);
        let e = col.get(100).unwrap();
        assert_eq!(e.movement.cell_position(), (5, 5));
        assert_eq!(e.state(), EntityState::Attacking);
    }

    #[test]
    fn skill_cast_cancel_resets_casting_state() {
        let mut col = EntityCollection::new();
        let mut entity = make_entity(100);
        entity.enter_casting(2.0, SkillEnum::MgFirebolt);
        assert_eq!(entity.state(), EntityState::Casting);
        col.insert(entity);

        col.apply_skill_cast_cancel(100);
        let e = col.get(100).unwrap();
        assert_eq!(e.state(), EntityState::Standing);
        assert_eq!(e.state_timer, 0.0);
        assert!(e.active_skill.is_none());
    }

    #[test]
    fn guild_changed_sets_emblem_and_clears_tag_on_leave() {
        let mut col = EntityCollection::new();
        let mut entity = make_entity(100);
        entity.guild_name = Some("Knights".to_string());
        col.insert(entity);

        col.apply_entity_guild_changed(100, 7, 42);
        let e = col.get(100).unwrap();
        assert_eq!(e.guild_id, 7);
        assert_eq!(e.guild_emblem_version, 42);
        assert_eq!(e.guild_name.as_deref(), Some("Knights"));

        col.apply_entity_guild_changed(100, 0, 0);
        let e = col.get(100).unwrap();
        assert_eq!(e.guild_id, 0);
        assert!(e.guild_name.is_none());
    }

    #[test]
    fn skill_cast_cancel_zero_targets_player() {
        let mut col = EntityCollection::new();
        col.set_player_id(100);
        let mut entity = make_entity(100);
        entity.enter_casting(1.5, SkillEnum::MgSight);
        col.insert(entity);

        col.apply_skill_cast_cancel(0);
        assert_eq!(col.player().unwrap().state(), EntityState::Standing);
    }

    fn make_entity_at(id: u32, x: u16, y: u16) -> Entity {
        Entity::new(
            id,
            EntityType::Player,
            0,
            1,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            x,
            y,
            0,
            150,
        )
    }

    #[test]
    fn autocounter_channel_freezes_caster_facing_the_enemy() {
        let mut col = EntityCollection::new();
        col.set_player_id(100);
        col.insert(make_entity_at(100, 10, 10));
        col.insert(make_entity_at(200, 10, 15));

        col.apply_autocounter_channel(100, Some(200), SkillEnum::KnAutocounter, 1.5);

        let e = col.get(100).unwrap();
        assert_eq!(e.state(), EntityState::Casting);
        assert_eq!(e.state_timer, 1.5);
        assert_eq!(e.cast_total_duration, 1.5);
        assert_eq!(e.active_skill, Some(SkillEnum::KnAutocounter));
        assert_eq!(
            e.direction,
            direction_from_positions(10, 10, 10, 15).unwrap()
        );

        let mut character = Character::default();
        character.skills.set_skills(vec![SkillData {
            skill: SkillEnum::KnAutocounter,
            level: 3,
            selected_level: 3,
            sp_cost: 0,
            attack_range: 0,
            upgradable: false,
            skill_target_type: SkillTargetType::Target,
        }]);
        let params = channel_params(&character, true, Some(200), None);
        assert_eq!(params.duration, 3.0 * 0.4);
        assert_eq!(params.face, Some(200));
        assert_eq!(
            channel_params(&character, false, Some(200), Some(300)).face,
            None
        );
    }

    #[test]
    fn action_failure_resets_player_only() {
        let mut col = EntityCollection::new();
        col.set_player_id(100);
        let mut player = make_entity(100);
        player.set_state(EntityState::Attacking);
        player.state_timer = 1.0;
        col.insert(player);

        let mut other = make_entity(200);
        other.set_state(EntityState::Attacking);
        col.insert(other);

        col.apply_action_failure();
        assert_eq!(col.player().unwrap().state(), EntityState::Standing);
        assert_eq!(col.player().unwrap().state_timer, 0.0);
        assert_eq!(col.get(200).unwrap().state(), EntityState::Attacking);
    }

    #[test]
    fn direction_and_name_and_emotion() {
        let mut col = EntityCollection::new();
        col.insert(make_entity(100));

        col.apply_entity_direction_changed(100, 2, 5);
        let e = col.get(100).unwrap();
        assert_eq!(e.head_dir, 2);
        assert_eq!(e.direction, 5);

        col.apply_entity_name_received(100, "Poring".to_string());
        assert_eq!(col.get(100).unwrap().name.as_deref(), Some("Poring"));

        col.apply_entity_emotion(100, 3, 1.4);
        assert!(col.get(100).unwrap().emotion.is_some());
        assert_eq!(
            col.get(100).unwrap().emotion.as_ref().unwrap().emotion_type,
            3
        );
    }

    #[test]
    fn skill_no_damage_faces_target() {
        let mut col = EntityCollection::new();
        let mut caster = Entity::new(
            1,
            EntityType::Player,
            0,
            1,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            5,
            5,
            0,
            150,
        );
        caster.set_facing(0);
        col.insert(caster);
        col.insert(Entity::new(
            2,
            EntityType::Monster,
            1002,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            8,
            5,
            0,
            200,
        ));

        col.apply_skill_no_damage(SkillEnum::MgSight, 1, 2);
        let e = col.get(1).unwrap();
        assert_eq!(e.direction, 6);
        assert_eq!(e.state(), EntityState::SkillExec);
    }

    #[test]
    fn run_toggle_plays_motion_on_start_but_not_when_stopping() {
        let run = SkillEnum::TkRun;

        // Start: the EFST_RUN change already flipped is_running on, so the skill
        // packet plays the run motion.
        let mut col = EntityCollection::new();
        let mut starter = make_entity(1);
        starter.is_running = true;
        col.insert(starter);
        col.apply_skill_no_damage(run, 1, 0);
        assert_eq!(col.get(1).unwrap().state(), EntityState::SkillExec);

        // Stop: is_running already flipped off, so the skill packet is ignored
        // and the character does not re-enter a walk motion in place.
        let mut col = EntityCollection::new();
        let mut runner = make_entity(1);
        runner.set_state(EntityState::Standing);
        col.insert(runner);
        col.apply_skill_no_damage(run, 1, 0);
        assert_eq!(col.get(1).unwrap().state(), EntityState::Standing);
    }

    #[test]
    fn prepare_kick_freezes_the_caster_on_its_stance_frame() {
        let mut col = EntityCollection::new();
        col.insert(make_entity(1));
        col.apply_skill_no_damage(SkillEnum::TkReadyturn, 1, 0);

        let e = col.get(1).unwrap();
        assert_eq!(e.state(), EntityState::SkillExec);
        assert_eq!(e.action_index(), 12);
        assert_eq!(e.skill_exec_start_frame(), 3);
        let mut forced = e.forced_animation.expect("stance poses the body");
        assert!(forced.hold);
        assert_eq!((forced.action, forced.start_frame), (12, 3));
        assert!(forced.tick_hold(1.0), "held for two seconds");
        assert!(!forced.tick_hold(1.5));

        // A skill without a stance leaves the body animating.
        col.insert(make_entity(2));
        col.apply_skill_no_damage(SkillEnum::AlHeal, 2, 0);
        assert!(col.get(2).unwrap().forced_animation.is_none());
    }

    #[test]
    fn skill_name_is_shouted_unless_the_skill_is_silent() {
        let mut names = HashMap::new();
        names.insert("TK_READYSTORM".to_string(), "Tornado Stance".to_string());
        let names = SkillNameTable::from_entries(names);

        let mut col = EntityCollection::new();
        col.insert(make_entity(1));

        col.show_skill_chat_bubble(1, SkillEnum::TkReadystorm, Some(&names));
        assert_eq!(
            col.get(1).unwrap().chat_bubble.as_ref().unwrap().message,
            "Tornado Stance !!"
        );

        // A skill the table does not name falls back to its internal id.
        col.get_mut(1).unwrap().chat_bubble = None;
        col.show_skill_chat_bubble(1, SkillEnum::AlHeal, Some(&names));
        assert_eq!(
            col.get(1).unwrap().chat_bubble.as_ref().unwrap().message,
            "AL_HEAL !!"
        );

        col.get_mut(1).unwrap().chat_bubble = None;
        col.show_skill_chat_bubble(1, SkillEnum::StChasewalk, Some(&names));
        assert!(col.get(1).unwrap().chat_bubble.is_none());

        let mut monster = make_entity(2);
        monster.entity_type = EntityType::Monster;
        col.insert(monster);
        col.show_skill_chat_bubble(2, SkillEnum::NpcDarkstrike, Some(&names));
        assert!(col.get(2).unwrap().chat_bubble.is_none());
    }

    #[test]
    fn a_stealthed_actor_neither_keeps_nor_gains_a_balloon() {
        use crate::sprite_path::{OPTION_CLOAK, OPTION_HIDE};

        let mut col = EntityCollection::new();
        col.insert(make_entity(1));
        col.show_skill_chat_bubble(1, SkillEnum::AlHeal, None);
        assert!(col.get(1).unwrap().chat_bubble.is_some());

        col.get_mut(1).unwrap().effect_state = OPTION_CLOAK;
        col.clear_hidden_chat_bubble(1);
        assert!(col.get(1).unwrap().chat_bubble.is_none());

        col.show_skill_chat_bubble(1, SkillEnum::AlHeal, None);
        assert!(col.get(1).unwrap().chat_bubble.is_none());

        col.insert(make_entity(2));
        col.set_player_id(2);
        col.get_mut(2).unwrap().effect_state = OPTION_HIDE;
        col.show_skill_chat_bubble(2, SkillEnum::AlHeal, None);
        assert!(col.get(2).unwrap().chat_bubble.is_some());
        col.clear_hidden_chat_bubble(2);
        assert!(col.get(2).unwrap().chat_bubble.is_some());
    }
}
