use models::enums::skill_enums::SkillEnum;

pub const HOTKEY_ROWS: usize = 4;
pub const HOTKEY_COLS: usize = 9;
pub const HOTKEY_TOTAL: usize = HOTKEY_ROWS * HOTKEY_COLS;
/// A controller and the on-screen controls reach the bar in sets of twelve: the 36 slots in three
pub const PAD_SET_SLOTS: usize = 12;
pub const PAD_SETS: u8 = (HOTKEY_TOTAL / PAD_SET_SLOTS) as u8;

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum HotkeySlotContent {
    Empty,
    Skill { skill: SkillEnum, level: i16 },
    Item { item_id: u32 },
}

pub struct HotkeyBar {
    slots: [HotkeySlotContent; HOTKEY_TOTAL],
    visible_rows: u8,
    battle_mode: bool,
}

impl Default for HotkeyBar {
    fn default() -> Self {
        Self::new()
    }
}

impl HotkeyBar {
    pub fn new() -> Self {
        Self {
            slots: [HotkeySlotContent::Empty; HOTKEY_TOTAL],
            visible_rows: 1,
            battle_mode: false,
        }
    }

    pub fn set_from_server(&mut self, keys: &[(i8, u32, i16)]) {
        for (i, &(is_skill, id, count)) in keys.iter().take(HOTKEY_TOTAL).enumerate() {
            self.slots[i] = if is_skill != 0 && id != 0 {
                // an id outside rAthena's skill db leaves the slot empty
                match SkillEnum::try_from_value(id) {
                    Ok(skill) => HotkeySlotContent::Skill {
                        skill,
                        level: count,
                    },
                    Err(_) => HotkeySlotContent::Empty,
                }
            } else if id != 0 {
                HotkeySlotContent::Item { item_id: id }
            } else {
                HotkeySlotContent::Empty
            };
        }
    }

    pub fn set_slot(&mut self, index: usize, content: HotkeySlotContent) {
        if index < HOTKEY_TOTAL {
            self.slots[index] = content;
        }
    }

    pub fn clear_slot(&mut self, index: usize) {
        if index < HOTKEY_TOTAL {
            self.slots[index] = HotkeySlotContent::Empty;
        }
    }

    pub fn get_slot(&self, index: usize) -> HotkeySlotContent {
        if index < HOTKEY_TOTAL {
            self.slots[index]
        } else {
            HotkeySlotContent::Empty
        }
    }

    pub fn cycle_visibility(&mut self) {
        self.visible_rows = (self.visible_rows + 1) % (HOTKEY_ROWS as u8 + 1);
    }

    pub fn visible_rows(&self) -> u8 {
        self.visible_rows
    }

    pub fn set_visible_rows(&mut self, rows: u8) {
        self.visible_rows = rows.min(HOTKEY_ROWS as u8);
    }

    pub fn toggle_battle_mode(&mut self) {
        self.battle_mode = !self.battle_mode;
    }

    pub fn battle_mode(&self) -> bool {
        self.battle_mode
    }

    pub fn set_battle_mode(&mut self, enabled: bool) {
        self.battle_mode = enabled;
    }

    pub fn to_server_format(&self, index: usize) -> (i8, u32, i16) {
        match self.get_slot(index) {
            HotkeySlotContent::Empty => (0, 0, 0),
            HotkeySlotContent::Skill { skill, level } => (1, skill.id(), level),
            HotkeySlotContent::Item { item_id } => (0, item_id as u32, 0),
        }
    }

    pub fn clear(&mut self) {
        self.slots = [HotkeySlotContent::Empty; HOTKEY_TOTAL];
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unknown_skill_leaves_the_slot_empty() {
        let mut bar = HotkeyBar::new();
        bar.set_from_server(&[(1, 9999, 5), (1, 2001, 5)]); // no skill in rAthena's db, then RK_ENCHANTBLADE
        assert!(matches!(bar.slots[0], HotkeySlotContent::Empty));
        assert!(matches!(
            bar.slots[1],
            HotkeySlotContent::Skill {
                skill: SkillEnum::RkEnchantblade,
                level: 5
            }
        ));
    }

    #[test]
    fn set_from_server_and_query() {
        let mut bar = HotkeyBar::new();
        let server_data = vec![
            (1i8, 28u32, 5i16), // Skill: id=28, level=5
            (0, 501, 0),        // Item: item_id=501
            (0, 0, 0),          // Empty
            (1, 10, 3),         // Skill: id=10, level=3
        ];
        bar.set_from_server(&server_data);

        assert_eq!(
            bar.get_slot(0),
            HotkeySlotContent::Skill {
                skill: SkillEnum::AlHeal,
                level: 5
            }
        );
        assert_eq!(bar.get_slot(1), HotkeySlotContent::Item { item_id: 501 });
        assert_eq!(bar.get_slot(2), HotkeySlotContent::Empty);
        assert_eq!(
            bar.get_slot(3),
            HotkeySlotContent::Skill {
                skill: SkillEnum::MgSight,
                level: 3
            }
        );
    }

    #[test]
    fn cycle_visibility() {
        let mut bar = HotkeyBar::new();
        assert_eq!(bar.visible_rows(), 1);
        bar.cycle_visibility();
        assert_eq!(bar.visible_rows(), 2);
        bar.cycle_visibility();
        assert_eq!(bar.visible_rows(), 3);
        bar.cycle_visibility();
        assert_eq!(bar.visible_rows(), 4);
        bar.cycle_visibility();
        assert_eq!(bar.visible_rows(), 0);
        bar.cycle_visibility();
        assert_eq!(bar.visible_rows(), 1);
    }

    #[test]
    fn set_and_clear_slot() {
        let mut bar = HotkeyBar::new();
        bar.set_slot(
            5,
            HotkeySlotContent::Skill {
                skill: SkillEnum::AlHeal,
                level: 10,
            },
        );
        assert_eq!(
            bar.get_slot(5),
            HotkeySlotContent::Skill {
                skill: SkillEnum::AlHeal,
                level: 10
            }
        );

        bar.set_slot(5, HotkeySlotContent::Item { item_id: 501 });
        assert_eq!(bar.get_slot(5), HotkeySlotContent::Item { item_id: 501 });

        bar.clear_slot(5);
        assert_eq!(bar.get_slot(5), HotkeySlotContent::Empty);
    }

    #[test]
    fn to_server_format_conversion() {
        let mut bar = HotkeyBar::new();
        bar.set_slot(
            0,
            HotkeySlotContent::Skill {
                skill: SkillEnum::AlHeal,
                level: 5,
            },
        );
        bar.set_slot(1, HotkeySlotContent::Item { item_id: 501 });

        assert_eq!(bar.to_server_format(0), (1, 28, 5));
        assert_eq!(bar.to_server_format(1), (0, 501, 0));
        assert_eq!(bar.to_server_format(2), (0, 0, 0));
    }
}
